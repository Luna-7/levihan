/**
 * 登录：昵称 + 密码。校验通过后签发自定义登录票据，前端用它换登录态。
 *
 * 与 registerWithPassword 一样走「事件函数 + HTTP 访问服务」，
 * 因为登录必然发生在获得登录态之前，网关策略默认不放行匿名 callFunction。
 *
 * 为什么不用 db.rpc()：runtime 里的 @cloudbase/node-sdk 3.18.3，app.rdb() 返回的
 * postgrest 客户端只暴露 from()/select()/insert()/update()，没有 rpc()。
 *
 * 安全约定：
 * - 昵称不存在与密码错误返回同一句提示，避免昵称枚举。
 * - 口令用 crypto.timingSafeEqual 做定长比较，避免时序侧信道。
 * - 〔待补〕目前没有失败次数限制，公网爆破防护需要后续在网关 QPS 策略或
 *   users 表加失败计数后补上。
 */
const crypto = require('crypto');
const tcb = require('@cloudbase/node-sdk');

const ALLOWED_ORIGINS = new Set([
  'https://levihan.asia',
  'https://www.levihan.asia',
]);
/**
 * 本地开发/预览端口不固定（`npm run dev` 跑 3000、`vite preview` 跑 4173、
 * vite 默认 5173，`--host` 时还可能是局域网 IP），逐个枚举必然漏 —— 之前只写了
 * 5173/4173，于是 dev（3000）下浏览器拿到的 Access-Control-Allow-Origin 是
 * https://levihan.asia，请求被丢，表现为「点了登录完全没反应」。
 * 注册/登录是匿名接口、不携带会话，CORS 在此不是安全边界，故本地与私有网段整体放行。
 */
const LOCAL_ORIGIN =
  /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\]|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})(:\d+)?$/;
const FALLBACK_ORIGIN = 'https://levihan.asia';
const isAllowedOrigin = (origin) => ALLOWED_ORIGINS.has(origin) || LOCAL_ORIGIN.test(origin);
const TICKET_REFRESH_MS = 30 * 24 * 60 * 60 * 1000;
const SCRYPT_KEYLEN = 64;
const NICKNAME_MIN = 2;
const NICKNAME_MAX = 20;
const PASSWORD_MIN = 6;
const PASSWORD_MAX = 64;
const CREDENTIAL_ERROR = '昵称或密码不正确';
const CONFIG_MESSAGE = '账号服务配置异常，请联系管理员';
const UNAVAILABLE_MESSAGE = '登录服务暂时不可用，请稍后重试';

function corsHeaders(event) {
  const headers = (event && event.headers) || {};
  const origin = headers.origin || headers.Origin || '';
  return {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': isAllowedOrigin(origin) ? origin : FALLBACK_ORIGIN,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    Vary: 'Origin',
  };
}

function respond(event, statusCode, body) {
  return { statusCode, headers: corsHeaders(event), body: JSON.stringify(body) };
}

function readPayload(event) {
  if (!event) return {};
  const isHttp = Boolean(event.httpMethod || event.requestContext || event.headers);
  if (!isHttp) return event;
  if (typeof event.body === 'string') {
    if (!event.body) return {};
    return JSON.parse(event.isBase64Encoded ? Buffer.from(event.body, 'base64').toString('utf8') : event.body);
  }
  return event.body && typeof event.body === 'object' ? event.body : {};
}

function data(result) {
  if (result.error) throw new Error(result.error.message);
  return result.data;
}

const firstRow = (value) => (Array.isArray(value) ? value[0] : value);

/** 环境 ID 必须是具体值：带 accessKey 初始化时 SYMBOL_CURRENT_ENV 解析不出凭证。 */
const ENV_ID = process.env.TCB_ENV || 'levihan-tudou-d0g7jivue1ccc4a35';

/** 数据面：服务端 API Key 映射 PostgreSQL 的 service_role，缺它会被 RLS / 表权限拒绝。 */
function initDb() {
  const accessKey = String(process.env.CLOUDBASE_APIKEY || '').trim();
  if (!accessKey || accessKey.startsWith('{{env.')) throw new Error('CLOUDBASE_APIKEY 未配置');
  return tcb.init({ env: ENV_ID, accessKey });
}

/**
 * 票据面：createTicket 用「自定义登录私钥」本地签 RS256 JWT，私钥 JSON 结构
 * { private_key_id, private_key, env_id }。
 *
 * 为什么默认按 base64 解：CLI 渲染 cloudbaserc 时给 JSON.parse 挂了 reviver
 * （「只解析对象」——凡长得像 JSON 的字符串值都会再被解析成对象），
 * 于是 .env 里直接放私钥 JSON 会被解析成对象，部署时报
 * `Environment.Variables.N.Value` 类型不是 string。base64 不含 {} " : ，
 * JSON.parse 失败因而保持字符串，可安全穿过该 reviver。
 * 也兼容控制台里直接填明文 JSON（形如 { 开头）。
 */
function parseCredentials(raw) {
  const text = raw.startsWith('{') ? raw : Buffer.from(raw, 'base64').toString('utf8');
  return JSON.parse(text);
}

function initAuth() {
  const raw = String(process.env.CUSTOM_LOGIN_CREDENTIALS || '').trim();
  if (!raw || raw.startsWith('{{env.')) throw new Error('CUSTOM_LOGIN_CREDENTIALS 未配置');
  let credentials;
  try {
    credentials = parseCredentials(raw);
  } catch {
    throw new Error('CUSTOM_LOGIN_CREDENTIALS 不是合法凭据（应为 base64 或 JSON）');
  }
  return tcb.init({ env: ENV_ID, credentials });
}

function verifyPassword(password, stored) {
  const parts = String(stored || '').split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const expected = Buffer.from(parts[2], 'hex');
  const actual = crypto.scryptSync(password, parts[1], SCRYPT_KEYLEN);
  if (expected.length !== actual.length) return false;
  return crypto.timingSafeEqual(actual, expected);
}

async function issueTicket(app, uid) {
  const issued = await Promise.resolve(app.auth().createTicket(uid, { refresh: TICKET_REFRESH_MS }));
  const ticket = typeof issued === 'string' ? issued : issued && issued.ticket;
  if (!ticket) throw new Error('TICKET_ISSUE_FAILED');
  return ticket;
}

exports.main = async (event) => {
  if (String((event && event.httpMethod) || '').toUpperCase() === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders(event), body: '' };
  }

  let payload;
  try {
    payload = readPayload(event);
  } catch {
    return respond(event, 400, { ok: false, message: '请求格式错误' });
  }

  const nickname = String(payload.nickname || '').trim();
  const password = String(payload.password || '');
  if (nickname.length < NICKNAME_MIN || nickname.length > NICKNAME_MAX || password.length < PASSWORD_MIN || password.length > PASSWORD_MAX) {
    return respond(event, 401, { ok: false, message: CREDENTIAL_ERROR });
  }

  try {
    const db = initDb().rdb({ database: 'public' });

    const credential = firstRow(
      data(
        await db
          .from('users')
          .select('uid,nickname,role,password_hash')
          .eq('nickname_key', nickname.toLowerCase())
          .limit(1)
      )
    );

    if (!credential || !credential.password_hash || !verifyPassword(password, credential.password_hash)) {
      return respond(event, 401, { ok: false, message: CREDENTIAL_ERROR });
    }
    if (credential.role === 'banned') {
      return respond(event, 403, { ok: false, message: '这个账号已被停用' });
    }

    const ticket = await issueTicket(initAuth(), credential.uid);
    return respond(event, 200, {
      ok: true,
      ticket,
      profile: { uid: credential.uid, nickname: credential.nickname, role: credential.role },
    });
  } catch (error) {
    const raw = String((error && error.message) || '');
    if (/permission denied|credentials|CLOUDBASE_APIKEY/i.test(raw)) {
      console.error('loginWithPassword config error', error);
      return respond(event, 503, { ok: false, message: CONFIG_MESSAGE });
    }
    console.error('loginWithPassword failed', error);
    return respond(event, 503, { ok: false, message: UNAVAILABLE_MESSAGE });
  }
};
